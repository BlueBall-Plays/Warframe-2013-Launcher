import configparser
from pathlib import Path
import subprocess

# Dossier du launcher
BASE_DIR = Path(__file__).parent

# Fichier de configuration
CONFIG_FILE = BASE_DIR / "option.ini"

config = configparser.ConfigParser()

# Lire la configuration existante
if CONFIG_FILE.exists():
    config.read(CONFIG_FILE, encoding="utf-8")


# Vérifier si une langue est déjà configurée
if "Launcher" in config and "Language" in config["Launcher"]:
    language = config["Launcher"]["Language"]
    print(f"Langue configurée : {language}")

else:
    print("Choisissez votre langue :")
    print("1. Français")
    print("2. English")

    choice = input("> ")

    if choice == "1":
        language = "fr"
    elif choice == "2":
        language = "en"
    else:
        print("Choix invalide.")
        exit()

    # Créer la section Launcher
    config["Launcher"] = {
        "Language": language
    }

    # Sauvegarder le choix
    with open(CONFIG_FILE, "w", encoding="utf-8") as file:
        config.write(file)

    print(f"Langue enregistrée : {language}")

    # Déterminer le launcher à utiliser
LANGUAGE_DIR = BASE_DIR / "Langues"

if language == "fr":
    launcher_path = LANGUAGE_DIR / "Warframe 2013 launcher FR.exe"
elif language == "en":
    launcher_path = LANGUAGE_DIR / "Warframe 2013 Launcher.exe"
else:
    print("Langue inconnue.")
    exit()

print(f"Launcher sélectionné : {launcher_path}")
subprocess.Popen([str(launcher_path)])
