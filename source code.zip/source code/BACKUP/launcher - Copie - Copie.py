import configparser
import subprocess
import tkinter as tk
from pathlib import Path


# =========================
# CONFIGURATION
# =========================

BASE_DIR = Path(__file__).parent
CONFIG_FILE = BASE_DIR / "option.ini"
LANGUAGE_DIR = BASE_DIR / "Langues"


# =========================
# FONCTIONS
# =========================

def save_language(language):
    config = configparser.ConfigParser()

    config["Launcher"] = {
        "language": language
    }

    with open(CONFIG_FILE, "w", encoding="utf-8") as file:
        config.write(file)


def get_language():
    config = configparser.ConfigParser()

    if not CONFIG_FILE.exists():
        return None

    config.read(CONFIG_FILE, encoding="utf-8")

    if "Launcher" not in config:
        return None

    language = config["Launcher"].get("language")

    if language not in ("fr", "en"):
        return None

    return language


def get_launcher_path(language):
    if language == "fr":
        return LANGUAGE_DIR / "Warframe 2013 launcher FR.exe"

    return LANGUAGE_DIR / "Warframe 2013 launcher.exe"


def start_launcher():
    launcher_path = get_launcher_path(language)

    if not launcher_path.exists():
        print(f"Launcher introuvable : {launcher_path}")
        return

    subprocess.Popen([str(launcher_path)])
    window.destroy()


def choose_language(selected_language):
    global language

    language = selected_language
    save_language(language)

    show_main_window()


# =========================
# FENÊTRE
# =========================

window = tk.Tk()

window.title("Warframe 2013 Launcher")
window.geometry("500x300")
window.resizable(False, False)

# Mettre la fenêtre au premier plan
window.attributes("-topmost", True)
window.lift()
window.focus_force()


def clear_window():
    for widget in window.winfo_children():
        widget.destroy()


# =========================
# ÉCRAN LANGUE
# =========================

def show_language_selection():

    clear_window()

    title = tk.Label(
        window,
        text="WARFRAME 2013 LAUNCHER",
        font=("Arial", 22, "bold")
    )
    title.pack(pady=(35, 20))

    text = tk.Label(
        window,
        text="Choose your language",
        font=("Arial", 13)
    )
    text.pack(pady=5)

    french_button = tk.Button(
        window,
        text="🇫🇷  Français",
        font=("Arial", 13),
        width=20,
        height=2,
        command=lambda: choose_language("fr")
    )
    french_button.pack(pady=8)

    english_button = tk.Button(
        window,
        text="🇬🇧  English",
        font=("Arial", 13),
        width=20,
        height=2,
        command=lambda: choose_language("en")
    )
    english_button.pack(pady=8)


# =========================
# ÉCRAN PRINCIPAL
# =========================

def show_main_window():

    clear_window()

    language_name = "Français" if language == "fr" else "English"

    title = tk.Label(
        window,
        text="WARFRAME 2013 LAUNCHER",
        font=("Arial", 22, "bold")
    )
    title.pack(pady=(45, 15))

    language_label = tk.Label(
        window,
        text=f"Language: {language_name}",
        font=("Arial", 12)
    )
    language_label.pack()

    start_button = tk.Button(
        window,
        text="START",
        font=("Arial", 16, "bold"),
        width=15,
        height=2,
        command=start_launcher
    )
    start_button.pack(pady=35)


# =========================
# DÉMARRAGE
# =========================

language = get_language()

if language is None:
    show_language_selection()
else:
    show_main_window()

window.mainloop()
