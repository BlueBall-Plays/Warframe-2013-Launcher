import configparser
import subprocess
import tkinter as tk
from pathlib import Path

# Dossier du launcher
BASE_DIR = Path(__file__).parent

# Fichier de configuration
CONFIG_FILE = BASE_DIR / "option.ini"

# Dossier contenant les launchers FR/EN
LANGUAGE_DIR = BASE_DIR / "Langues"

# Lire la configuration
config = configparser.ConfigParser()

if CONFIG_FILE.exists():
    config.read(CONFIG_FILE, encoding="utf-8")


# Choisir la langue si elle n'existe pas encore
if "Launcher" in config and "language" in config["Launcher"]:
    language = config["Launcher"]["language"]

else:
    print("Choisissez votre langue :")
    print("1. Français")
    print("2. English")

    choice = input("> ")

    if choice == "1":
        language = "fr"
    elif choice == "2":
        language = "en"
    else:
        print("Choix invalide.")
        exit()

    config["Launcher"] = {
        "language": language
    }

    with open(CONFIG_FILE, "w", encoding="utf-8") as file:
        config.write(file)


# Déterminer le launcher à utiliser
if language == "fr":
    launcher_path = LANGUAGE_DIR / "Warframe 2013 launcher FR.exe"
elif language == "en":
    launcher_path = LANGUAGE_DIR / "Warframe 2013 launcher.exe"
else:
    print("Langue inconnue.")
    exit()


# Fonction du bouton START
def start_launcher():
    if launcher_path.exists():
        subprocess.Popen([str(launcher_path)])
        window.destroy()
    else:
        print(f"Launcher introuvable : {launcher_path}")


# Création de la fenêtre
window = tk.Tk()
window.title("Warframe 2013 Launcher")
window.geometry("500x300")
window.resizable(False, False)

# Titre
title = tk.Label(
    window,
    text="WARFRAME 2013 LAUNCHER",
    font=("Arial", 22, "bold")
)
title.pack(pady=50)

# Langue affichée
language_text = "Français" if language == "fr" else "English"

label = tk.Label(
    window,
    text=f"Language: {language_text}",
    font=("Arial", 12)
)
label.pack()

# Bouton START
start_button = tk.Button(
    window,
    text="START",
    font=("Arial", 16, "bold"),
    width=15,
    height=2,
    command=start_launcher
)
start_button.pack(pady=30)

# Lancer la fenêtre
window.mainloop()
