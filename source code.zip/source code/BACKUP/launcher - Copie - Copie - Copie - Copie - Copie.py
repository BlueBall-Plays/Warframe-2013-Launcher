import configparser
import subprocess
import tkinter as tk
from tkinter import filedialog, messagebox
from pathlib import Path
import sys

# =========================
# CONFIGURATION
# =========================

if getattr(sys, "frozen", False):
    BASE_DIR = Path(sys.executable).parent
else:
    BASE_DIR = Path(__file__).parent
CONFIG_FILE = BASE_DIR / "option.ini"
LANGUAGE_DIR = BASE_DIR / "Langues"

WARFRAME_RELATIVE_PATH = Path(
    "steamapps",
    "content",
    "app_230410",
    "depot_230411"
)


# =========================
# TRADUCTIONS
# =========================

TRANSLATIONS = {
    "fr": {
        "title": "WARFRAME 2013 LAUNCHER",
        "language": "Langue : Français",
        "choose_language": "Choisissez votre langue",
        "start": "DÉMARRER",
        "settings": "PARAMÈTRES",
        "settings_title": "PARAMÈTRES",
        "save": "ENREGISTRER",
        "french": "🇫🇷 Français",
        "english": "🇬🇧 Anglais",

        "warframe_path": "Chemin de Warframe 2013",
        "server_path": "Chemin de SpaceNinjaServer",
        "browse": "PARCOURIR",

        "detecting": "Recherche de Warframe 2013...",
        "warframe_found": "Warframe 2013 trouvé !",
        "warframe_not_found":
            "Warframe 2013 n'a pas été trouvé automatiquement.",

        "select_warframe":
            "Sélectionnez le dossier depot_230411",

        "multiple_warframe":
            "Plusieurs installations de Warframe 2013 ont été trouvées.",

        "select_installation":
            "Sélectionnez l'installation à utiliser.",

        "server_title": "SpaceNinjaServer",

        "server_message":
            "Veuillez sélectionner le dossier de votre SpaceNinjaServer.",

        "select_server":
            "Sélectionnez le dossier SpaceNinjaServer",

        "invalid_folder":
            "Ce dossier ne semble pas être le bon.",

        "bat_missing":
            "Le fichier BAT est introuvable.",

        "wait_server":
            "Temps d'attente du serveur",

        "seconds":
            "secondes",

        "wait_invalid":
            "Veuillez entrer un nombre entier de secondes.",

        "wait_positive":
            "Le temps d'attente doit être supérieur ou égal à 0."
    },

    "en": {
        "title": "WARFRAME 2013 LAUNCHER",
        "language": "Language: English",
        "choose_language": "Choose your language",
        "start": "START",
        "settings": "SETTINGS",
        "settings_title": "SETTINGS",
        "save": "SAVE",
        "french": "🇫🇷 French",
        "english": "🇬🇧 English",

        "warframe_path": "Warframe 2013 path",
        "server_path": "SpaceNinjaServer path",
        "browse": "BROWSE",

        "detecting": "Searching for Warframe 2013...",
        "warframe_found": "Warframe 2013 found!",
        "warframe_not_found":
            "Warframe 2013 could not be found automatically.",

        "select_warframe":
            "Select the depot_230411 folder",

        "multiple_warframe":
            "Multiple Warframe 2013 installations were found.",

        "select_installation":
            "Select the installation to use.",

        "server_title": "SpaceNinjaServer",

        "server_message":
            "Please select your SpaceNinjaServer folder.",

        "select_server":
            "Select your SpaceNinjaServer folder",

        "invalid_folder":
            "This folder does not appear to be correct.",

        "bat_missing":
            "The BAT file could not be found.",

        "wait_server":
            "Server waiting time",

        "seconds":
            "seconds",

        "wait_invalid":
            "Please enter a whole number of seconds.",

        "wait_positive":
            "The waiting time must be greater than or equal to 0."
    }
}


# =========================
# CONFIGURATION INI
# =========================

def load_config():

    config = configparser.ConfigParser()

    if CONFIG_FILE.exists():
        config.read(CONFIG_FILE, encoding="utf-8")

    return config


config = load_config()


def save_config():

    with open(CONFIG_FILE, "w", encoding="utf-8") as file:
        config.write(file)


def get_language():

    config_file = load_config()

    if "Launcher" not in config_file:
        return None

    language = config_file["Launcher"].get("language")

    if language not in ("fr", "en"):
        return None

    return language


# =========================
# BAT SELON LA LANGUE
# =========================

def get_bat_path(language):

    if language == "fr":
        return LANGUAGE_DIR / "Warframe 2013 Launcher FR.bat"

    return LANGUAGE_DIR / "Warframe 2013 Launcher.bat"


# =========================
# MODIFICATION DU BAT
# =========================

def update_bat_paths(
    warframe_path,
    server_path,
    wait_server
):

    bat_path = get_bat_path(language)

    if not bat_path.exists():

        texts = TRANSLATIONS[language]

        messagebox.showerror(
            texts["bat_missing"],
            f"{texts['bat_missing']}\n\n{bat_path}"
        )

        return False

    try:

        with open(
            bat_path,
            "r",
            encoding="utf-8"
        ) as file:

            content = file.read()

        lines = content.splitlines()
        new_lines = []

        found_warframe = False
        found_server = False
        found_wait = False

        for line in lines:

            stripped = line.strip().lower()

            # =========================
            # PATH WARFRAME
            # =========================

            if stripped.startswith(
                'set "pathwarframe='
            ):

                new_lines.append(
                    f'set "PATHWarframe={warframe_path}"'
                )

                found_warframe = True

            # =========================
            # PATH SERVER
            # =========================

            elif stripped.startswith(
                'set "pathserver='
            ):

                new_lines.append(
                    f'set "PATHServer={server_path}"'
                )

                found_server = True

            # =========================
            # WAIT SERVER
            # =========================

            elif stripped.startswith(
                'set "wait_server='
            ):

                new_lines.append(
                    f'set "WAIT_SERVER={wait_server}"'
                )

                found_wait = True

            else:

                new_lines.append(line)

        # Si une variable n'existe pas dans le BAT,
        # on l'ajoute après @echo off.

        if not found_warframe:

            new_lines.insert(
                1,
                f'set "PATHWarframe={warframe_path}"'
            )

        if not found_server:

            insert_position = 2 if not found_warframe else 2

            new_lines.insert(
                insert_position,
                f'set "PATHServer={server_path}"'
            )

        if not found_wait:

            new_lines.insert(
                3,
                f'set "WAIT_SERVER={wait_server}"'
            )

        new_content = "\n".join(new_lines)

        with open(
            bat_path,
            "w",
            encoding="utf-8"
        ) as file:

            file.write(new_content)

        return True

    except Exception as error:

        messagebox.showerror(
            "Error",
            f"Impossible de modifier le BAT.\n\n{error}"
        )

        return False


# =========================
# RECHERCHE WARFRAME
# =========================

def find_warframe_installations():

    results = []

    for letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":

        drive = Path(f"{letter}:/")

        if not drive.exists():
            continue

        steam_candidates = [

            drive / "Steam",

            drive / "steam",

            drive / "Program Files" / "Steam",

            drive / "Program Files (x86)" / "Steam",

            drive / "Program Files" / "steam",

            drive / "Program Files (x86)" / "steam"
        ]

        for steam_path in steam_candidates:

            if not steam_path.is_dir():
                continue

            warframe_path = (
                steam_path /
                WARFRAME_RELATIVE_PATH
            )

            if warframe_path.is_dir():

                if warframe_path not in results:

                    results.append(warframe_path)

    return results


# =========================
# ÉCRAN CONFIGURATION
# =========================

def show_configuration_screen():

    clear_window()

    texts = TRANSLATIONS[language]

    title = tk.Label(
        window,
        text=texts["title"],
        font=("Arial", 20, "bold")
    )

    title.pack(
        pady=(30, 20)
    )

    status = tk.Label(
        window,
        text=texts["detecting"],
        font=("Arial", 13)
    )

    status.pack(
        pady=10
    )

    window.update()

    window.after(
        800,
        lambda: continue_warframe_detection(status)
    )


def continue_warframe_detection(status):

    texts = TRANSLATIONS[language]

    found_paths = find_warframe_installations()

    # UNE INSTALLATION

    if len(found_paths) == 1:

        warframe_path = found_paths[0]

        status.config(
            text=(
                f"✓ {texts['warframe_found']}\n\n"
                f"{warframe_path}"
            )
        )

        window.update()

        window.after(
            1500,
            lambda: ask_server_path(warframe_path)
        )

        return

    # PLUSIEURS INSTALLATIONS

    if len(found_paths) > 1:

        show_multiple_warframe(found_paths)

        return

    # AUCUNE INSTALLATION

    status.config(
        text=texts["warframe_not_found"]
    )

    window.update()

    window.after(
        800,
        ask_manual_warframe
    )


# =========================
# PLUSIEURS WARFRAME
# =========================

def show_multiple_warframe(paths):

    clear_window()

    texts = TRANSLATIONS[language]

    title = tk.Label(
        window,
        text=texts["multiple_warframe"],
        font=("Arial", 13, "bold")
    )

    title.pack(
        pady=(25, 10)
    )

    label = tk.Label(
        window,
        text=texts["select_installation"],
        font=("Arial", 11)
    )

    label.pack(
        pady=5
    )

    selected = tk.StringVar()

    for path in paths:

        radio = tk.Radiobutton(
            window,
            text=str(path),
            variable=selected,
            value=str(path),
            anchor="w"
        )

        radio.pack(
            fill="x",
            padx=20,
            pady=4
        )

    def confirm():

        if not selected.get():
            return

        ask_server_path(
            Path(selected.get())
        )

    button = tk.Button(
        window,
        text=texts["save"],
        width=15,
        command=confirm
    )

    button.pack(
        pady=15
    )


# =========================
# WARFRAME MANUEL
# =========================

def ask_manual_warframe():

    texts = TRANSLATIONS[language]

    folder = filedialog.askdirectory(
        title=texts["select_warframe"]
    )

    if not folder:
        return

    path = Path(folder)

    if path.name.lower() != "depot_230411":

        messagebox.showerror(
            texts["warframe_path"],
            texts["invalid_folder"]
        )

        return

    ask_server_path(path)


# =========================
# SPACE NINJA SERVER
# =========================

def ask_server_path(warframe_path):

    texts = TRANSLATIONS[language]

    clear_window()

    title = tk.Label(
        window,
        text=texts["server_title"],
        font=("Arial", 20, "bold")
    )

    title.pack(
        pady=(35, 15)
    )

    message = tk.Label(
        window,
        text=texts["server_message"],
        font=("Arial", 12),
        wraplength=430
    )

    message.pack(
        pady=15
    )

    browse_button = tk.Button(
        window,
        text=texts["browse"],
        font=("Arial", 12, "bold"),
        width=18,
        height=2,
        command=lambda: choose_server(
            warframe_path
        )
    )

    browse_button.pack(
        pady=20
    )


def choose_server(warframe_path):

    texts = TRANSLATIONS[language]

    folder = filedialog.askdirectory(
        title=texts["select_server"]
    )

    if not folder:
        return

    server_path = Path(folder)

    if not server_path.is_dir():

        messagebox.showerror(
            texts["server_path"],
            texts["invalid_folder"]
        )

        return

    save_paths(
        warframe_path,
        server_path
    )


# =========================
# SAUVEGARDE DES CHEMINS
# =========================

def save_paths(
    warframe_path,
    server_path
):

    global config

    if "Launcher" not in config:
        config["Launcher"] = {}

    config["Launcher"]["warframe_path"] = str(
        warframe_path
    )

    config["Launcher"]["server_path"] = str(
        server_path
    )

    # Valeur par défaut
    if not config["Launcher"].get(
        "wait_server"
    ):

        config["Launcher"]["wait_server"] = "15"

    save_config()

    wait_server = config["Launcher"].get(
        "wait_server",
        fallback="15"
    )

    update_bat_paths(
        warframe_path,
        server_path,
        wait_server
    )

    show_main_window()


# =========================
# START
# =========================

def start_launcher():

    bat_path = get_bat_path(language)

    if not bat_path.exists():

        messagebox.showerror(
            "Error",
            f"BAT introuvable :\n{bat_path}"
        )

        return

    try:

        subprocess.Popen(
            ["cmd", "/c", str(bat_path)],
            cwd=str(bat_path.parent)
        )

        window.destroy()

    except Exception as error:

        messagebox.showerror(
            "Error",
            f"Impossible de lancer le BAT.\n\n{error}"
        )


# =========================
# CHOIX DE LANGUE
# =========================

def choose_language(selected_language):

    global language
    global config

    language = selected_language

    config = load_config()

    if "Launcher" not in config:

        config["Launcher"] = {}

    config["Launcher"]["language"] = language

    save_config()

    warframe_path = config["Launcher"].get(
        "warframe_path",
        fallback=""
    )

    server_path = config["Launcher"].get(
        "server_path",
        fallback=""
    )

    wait_server = config["Launcher"].get(
        "wait_server",
        fallback="15"
    )

    if (
        warframe_path
        and server_path
        and Path(warframe_path).is_dir()
        and Path(server_path).is_dir()
    ):

        update_bat_paths(
            warframe_path,
            server_path,
            wait_server
        )

        show_main_window()

    else:

        show_configuration_screen()


# =========================
# FENÊTRE
# =========================

window = tk.Tk()

window.title(
    "Warframe 2013 Launcher"
)

window.geometry(
    "500x300"
)

window.resizable(
    False,
    False
)

window.attributes(
    "-topmost",
    True
)

window.lift()

window.focus_force()


def clear_window():

    for widget in window.winfo_children():
        widget.destroy()


# =========================
# SÉLECTION LANGUE
# =========================

def show_language_selection():

    clear_window()

    texts = TRANSLATIONS["fr"]

    title = tk.Label(
        window,
        text=texts["title"],
        font=("Arial", 22, "bold")
    )

    title.pack(
        pady=(35, 20)
    )

    text = tk.Label(
        window,
        text=texts["choose_language"],
        font=("Arial", 13)
    )

    text.pack(
        pady=5
    )

    french_button = tk.Button(
        window,
        text=texts["french"],
        font=("Arial", 13),
        width=20,
        height=2,
        command=lambda: choose_language("fr")
    )

    french_button.pack(
        pady=8
    )

    english_button = tk.Button(
        window,
        text=texts["english"],
        font=("Arial", 13),
        width=20,
        height=2,
        command=lambda: choose_language("en")
    )

    english_button.pack(
        pady=8
    )


# =========================
# PARAMÈTRES
# =========================

def open_settings():

    texts = TRANSLATIONS[language]

    settings_window = tk.Toplevel(
        window
    )

    settings_window.title(
        texts["settings_title"]
    )

    settings_window.geometry(
        "380x300"
    )

    settings_window.resizable(
        False,
        False
    )

    settings_window.attributes(
        "-topmost",
        True
    )

    settings_window.lift()

    settings_window.focus_force()

    title = tk.Label(
        settings_window,
        text=texts["settings_title"],
        font=("Arial", 18, "bold")
    )

    title.pack(
        pady=15
    )

    # =========================
    # LANGUE
    # =========================

    language_label = tk.Label(
        settings_window,
        text=texts["language"],
        font=("Arial", 12)
    )

    language_label.pack()

    selected_language = tk.StringVar(
        value=language
    )

    french_button = tk.Radiobutton(
        settings_window,
        text=texts["french"],
        variable=selected_language,
        value="fr"
    )

    french_button.pack()

    english_button = tk.Radiobutton(
        settings_window,
        text=texts["english"],
        variable=selected_language,
        value="en"
    )

    english_button.pack()

    # =========================
    # TEMPS D'ATTENTE
    # =========================

    wait_label = tk.Label(
        settings_window,
        text=texts["wait_server"],
        font=("Arial", 12, "bold")
    )

    wait_label.pack(
        pady=(15, 5)
    )

    current_wait = config["Launcher"].get(
        "wait_server",
        fallback="15"
    )

    wait_frame = tk.Frame(
        settings_window
    )

    wait_frame.pack()

    wait_entry = tk.Entry(
        wait_frame,
        width=8,
        justify="center",
        font=("Arial", 12)
    )

    wait_entry.insert(
        0,
        current_wait
    )

    wait_entry.pack(
        side="left"
    )

    seconds_label = tk.Label(
        wait_frame,
        text=f" {texts['seconds']}",
        font=("Arial", 11)
    )

    seconds_label.pack(
        side="left"
    )

    # =========================
    # ENREGISTRER
    # =========================

    def save_settings():

        global language
        global config

        # Vérifier le temps
        try:

            wait_server = int(
                wait_entry.get()
            )

        except ValueError:

            messagebox.showerror(
                texts["settings_title"],
                texts["wait_invalid"]
            )

            return

        if wait_server < 0:

            messagebox.showerror(
                texts["settings_title"],
                texts["wait_positive"]
            )

            return

        language = selected_language.get()

        config = load_config()

        if "Launcher" not in config:

            config["Launcher"] = {}

        config["Launcher"]["language"] = language

        config["Launcher"]["wait_server"] = str(
            wait_server
        )

        warframe_path = config["Launcher"].get(
            "warframe_path",
            fallback=""
        )

        server_path = config["Launcher"].get(
            "server_path",
            fallback=""
        )

        save_config()

        # =========================
        # MODIFIER LE BAT
        # =========================

        if (
            warframe_path
            and server_path
            and Path(warframe_path).is_dir()
            and Path(server_path).is_dir()
        ):

            update_bat_paths(
                warframe_path,
                server_path,
                wait_server
            )

        settings_window.destroy()

        show_main_window()

    save_button = tk.Button(
        settings_window,
        text=texts["save"],
        font=("Arial", 12, "bold"),
        width=12,
        command=save_settings
    )

    save_button.pack(
        pady=18
    )


# =========================
# ÉCRAN PRINCIPAL
# =========================

def show_main_window():

    clear_window()

    texts = TRANSLATIONS[language]

    title = tk.Label(
        window,
        text=texts["title"],
        font=("Arial", 22, "bold")
    )

    title.pack(
        pady=(45, 15)
    )

    language_label = tk.Label(
        window,
        text=texts["language"],
        font=("Arial", 12)
    )

    language_label.pack()

    start_button = tk.Button(
        window,
        text=texts["start"],
        font=("Arial", 16, "bold"),
        width=15,
        height=2,
        command=start_launcher
    )

    start_button.pack(
        pady=35
    )

    settings_button = tk.Button(
        window,
        text=texts["settings"],
        font=("Arial", 12),
        width=15,
        command=open_settings
    )

    settings_button.pack(
        pady=5
    )


# =========================
# DÉMARRAGE
# =========================

language = get_language()

if language is None:

    show_language_selection()

else:

    warframe_path = config["Launcher"].get(
        "warframe_path",
        fallback=""
    )

    server_path = config["Launcher"].get(
        "server_path",
        fallback=""
    )

    # Ajouter la valeur par défaut si elle n'existe pas
    if "wait_server" not in config["Launcher"]:

        config["Launcher"]["wait_server"] = "15"

        save_config()

    wait_server = config["Launcher"].get(
        "wait_server",
        fallback="15"
    )

    if (
        warframe_path
        and Path(warframe_path).is_dir()
        and server_path
        and Path(server_path).is_dir()
    ):

        # Synchroniser le BAT au démarrage
        update_bat_paths(
            warframe_path,
            server_path,
            wait_server
        )

        show_main_window()

    else:

        show_configuration_screen()


window.mainloop()
