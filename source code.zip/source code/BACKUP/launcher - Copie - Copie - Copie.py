import configparser
import subprocess
import tkinter as tk
from pathlib import Path


# =========================
# CONFIGURATION
# =========================

BASE_DIR = Path(__file__).parent
CONFIG_FILE = BASE_DIR / "option.ini"
LANGUAGE_DIR = BASE_DIR / "Langues"


# =========================
# TRADUCTIONS
# =========================

TRANSLATIONS = {
    "fr": {
        "title": "WARFRAME 2013 LAUNCHER",
        "language": "Langue : Français",
        "choose_language": "Choisissez votre langue",
        "start": "DÉMARRER",
        "settings": "PARAMÈTRES",
        "settings_title": "PARAMÈTRES",
        "save": "ENREGISTRER",
        "french": "🇫🇷 Français",
        "english": "🇬🇧 Anglais"
    },

    "en": {
        "title": "WARFRAME 2013 LAUNCHER",
        "language": "Language: English",
        "choose_language": "Choose your language",
        "start": "START",
        "settings": "SETTINGS",
        "settings_title": "SETTINGS",
        "save": "SAVE",
        "french": "🇫🇷 French",
        "english": "🇬🇧 English"
    }
}


# =========================
# FONCTIONS
# =========================

def save_language(language):
    config = configparser.ConfigParser()

    config["Launcher"] = {
        "language": language
    }

    with open(CONFIG_FILE, "w", encoding="utf-8") as file:
        config.write(file)


def get_language():
    config = configparser.ConfigParser()

    if not CONFIG_FILE.exists():
        return None

    config.read(CONFIG_FILE, encoding="utf-8")

    if "Launcher" not in config:
        return None

    language = config["Launcher"].get("language")

    if language not in ("fr", "en"):
        return None

    return language


def get_launcher_path(language):
    if language == "fr":
        return LANGUAGE_DIR / "Warframe 2013 launcher FR.exe"

    return LANGUAGE_DIR / "Warframe 2013 launcher.exe"


def start_launcher():
    launcher_path = get_launcher_path(language)

    if not launcher_path.exists():
        print(f"Launcher introuvable : {launcher_path}")
        return

    subprocess.Popen([str(launcher_path)])
    window.destroy()


def choose_language(selected_language):
    global language

    language = selected_language
    save_language(language)

    show_main_window()


# =========================
# FENÊTRE PRINCIPALE
# =========================

window = tk.Tk()

window.title("Warframe 2013 Launcher")
window.geometry("500x300")
window.resizable(False, False)

# Mettre la fenêtre au premier plan
window.attributes("-topmost", True)
window.lift()
window.focus_force()


def clear_window():
    for widget in window.winfo_children():
        widget.destroy()


# =========================
# ÉCRAN DE SÉLECTION DE LANGUE
# =========================

def show_language_selection():

    clear_window()

    texts = TRANSLATIONS["fr"]

    title = tk.Label(
        window,
        text=texts["title"],
        font=("Arial", 22, "bold")
    )
    title.pack(pady=(35, 20))

    text = tk.Label(
        window,
        text=texts["choose_language"],
        font=("Arial", 13)
    )
    text.pack(pady=5)

    french_button = tk.Button(
        window,
        text=texts["french"],
        font=("Arial", 13),
        width=20,
        height=2,
        command=lambda: choose_language("fr")
    )
    french_button.pack(pady=8)

    english_button = tk.Button(
        window,
        text=texts["english"],
        font=("Arial", 13),
        width=20,
        height=2,
        command=lambda: choose_language("en")
    )
    english_button.pack(pady=8)


# =========================
# PARAMÈTRES
# =========================

def open_settings():

    texts = TRANSLATIONS[language]

    settings_window = tk.Toplevel(window)

    settings_window.title(texts["settings_title"])
    settings_window.geometry("350x220")
    settings_window.resizable(False, False)

    settings_window.attributes("-topmost", True)
    settings_window.lift()
    settings_window.focus_force()

    title = tk.Label(
        settings_window,
        text=texts["settings_title"],
        font=("Arial", 18, "bold")
    )
    title.pack(pady=20)

    language_label = tk.Label(
        settings_window,
        text=texts["language"],
        font=("Arial", 12)
    )
    language_label.pack()

    selected_language = tk.StringVar(value=language)

    french_button = tk.Radiobutton(
        settings_window,
        text=texts["french"],
        variable=selected_language,
        value="fr"
    )
    french_button.pack()

    english_button = tk.Radiobutton(
        settings_window,
        text=texts["english"],
        variable=selected_language,
        value="en"
    )
    english_button.pack()

    def save_settings():

        global language

        language = selected_language.get()

        save_language(language)

        settings_window.destroy()

        show_main_window()

    save_button = tk.Button(
        settings_window,
        text=texts["save"],
        font=("Arial", 12, "bold"),
        width=12,
        command=save_settings
    )
    save_button.pack(pady=15)


# =========================
# ÉCRAN PRINCIPAL
# =========================

def show_main_window():

    clear_window()

    texts = TRANSLATIONS[language]

    title = tk.Label(
        window,
        text=texts["title"],
        font=("Arial", 22, "bold")
    )
    title.pack(pady=(45, 15))

    language_label = tk.Label(
        window,
        text=texts["language"],
        font=("Arial", 12)
    )
    language_label.pack()

    start_button = tk.Button(
        window,
        text=texts["start"],
        font=("Arial", 16, "bold"),
        width=15,
        height=2,
        command=start_launcher
    )
    start_button.pack(pady=35)

    settings_button = tk.Button(
        window,
        text=texts["settings"],
        font=("Arial", 12),
        width=15,
        command=open_settings
    )
    settings_button.pack(pady=5)


# =========================
# DÉMARRAGE
# =========================

language = get_language()

if language is None:
    show_language_selection()
else:
    show_main_window()

window.mainloop()
