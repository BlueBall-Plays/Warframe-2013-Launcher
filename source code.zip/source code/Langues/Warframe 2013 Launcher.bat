@echo off
title OpenWF - Warframe 2013

set "PATHWarframe="
set "PATHServer="
set "WAIT_SERVER=15"

echo Starting SpaceNinjaServer...
cd /d "%PATHServer%"

start "OPENWF_SERVER" cmd /c "set PATH=C:\Program Files\nodejs;%PATH%&& npm run raw"

echo Waiting for the server to start...
timeout /t %WAIT_SERVER% /nobreak >nul

echo Obsidienne:
echo Have fun, sir.
echo Launching the executable in 5 seconds.
timeout /t 5 /nobreak >nul

echo Starting Warframe 2013...
cd /d "%PATHWarframe%"
start "" "Warframe.x64.exe"

echo.
echo ============================================================================
echo Warframe is running.
echo If the server is inaccessible, please wait 5 seconds and try again.
echo Close Warframe to stop the server.
echo ============================================================================
echo.

:WAIT
timeout /t 2 /nobreak >nul
tasklist /FI "IMAGENAME eq Warframe.x64.exe" | find /I "Warframe.x64.exe" >nul

if not errorlevel 1 goto WAIT

echo.
echo Warframe has been closed.
echo Stopping SpaceNinjaServer...

taskkill /IM node.exe /T /F >nul 2>&1

echo ========================================================
echo Server stopped.
echo Thank you for using the SBBNO AI. Have a nice day!
echo ========================================================

timeout /t 6 /nobreak >nul
exit