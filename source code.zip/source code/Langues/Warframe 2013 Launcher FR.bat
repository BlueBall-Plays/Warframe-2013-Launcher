@echo off
title OpenWF - Warframe 2013

set "PATHWarframe=D:\Steam\steamapps\content\app_230410\depot_230411"
set "PATHServer=C:\Users\0esti\SpaceNinjaServer"
set "WAIT_SERVER=15"

echo Demarrage de SpaceNinjaServer...
cd /d "%PATHServer%"

start "OPENWF_SERVER" cmd /c "set PATH=C:\Program Files\nodejs;%PATH%&& npm run raw"

echo Attente du demarrage du serveur...
timeout /t %WAIT_SERVER% /nobreak >nul

echo Obsidienne :
echo Bon jeu monsieur.
echo Lancement de l'executable dans 5 secondes.
timeout /t 5 /nobreak >nul

echo Demarrage de Warframe 2013...
cd /d "%PATHWarframe%"
start "" "Warframe.x64.exe"

echo.
echo ============================================================================
echo Warframe est lance.
echo Si le serveur est inaccessible, veuillez attendre 5 secondes puis reessayer.
echo Fermez Warframe pour arreter le serveur.
echo ============================================================================
echo.

:WAIT
timeout /t 2 /nobreak >nul
tasklist /FI "IMAGENAME eq Warframe.x64.exe" | find /I "Warframe.x64.exe" >nul

if not errorlevel 1 goto WAIT

echo.
echo Warframe est ferme.
echo Arret de SpaceNinjaServer...

taskkill /IM node.exe /T /F >nul 2>&1

echo ========================================================
echo Serveur arrete.
echo Merci d'avoir utilise l'IA de la SBBNO. Bonne journee !
echo ========================================================

timeout /t 6 /nobreak >nul
exit